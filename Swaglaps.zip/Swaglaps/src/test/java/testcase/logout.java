package testcase;

import base.basetest;
import pages.logoutpage;
import pages.loginpage;
import utilities.readXLData;

import java.io.IOException;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

@Listeners(base.Listeners.class)
public class logout extends basetest {
    
    logoutpage logout;
    loginpage login;

   
    @Test(dataProviderClass = readXLData.class, dataProvider = "testData")
    public void logout(String Email, String password) throws InterruptedException, IOException {
    	
    	softAssert = new SoftAssert();
    	assertionMessage = new ThreadLocal<>();
        
        login = new loginpage(driver);
        logout = new logoutpage(driver);

        // Perform login actions
        login.enterEmail(Email);
        login.enterPassword(password);
        login.clickonbtn_login();

        // Perform logout actions
        logout.clickonbtn_menu();
        Thread.sleep(1000);
        logout.clickonbtn_logout();
    }
}
