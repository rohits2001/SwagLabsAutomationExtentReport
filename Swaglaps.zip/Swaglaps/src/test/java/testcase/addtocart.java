package testcase;

import base.basetest;
import pages.addtocartpage;
import pages.loginpage;
import utilities.readXLData;

import java.io.IOException;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(base.Listeners.class)
public class addtocart extends basetest {
    
    addtocartpage addtocart;
    loginpage login;
    
    @Test(dataProviderClass = readXLData.class, dataProvider = "testData")
    public void addToCart(String Email, String password, String firstname, String lastname, String zipcode) throws InterruptedException, IOException {
    	
    	login = new loginpage(driver);
    	addtocart = new addtocartpage(driver);
		login.enterEmail(Email);
		login.enterPassword(password);
		login.clickonbtn_login();
        
        // Initialize Add to Cart page object
    	
        
        // Perform actions on the page
        addtocart.clickonbtn_addtocart();
        addtocart.clickonbtn_gotocart();
        addtocart.clickonbtn_checkout();
        addtocart.enterfirstname(firstname);
        addtocart.enterlastname(lastname);
        addtocart.enterzipcode(zipcode);
        addtocart.clickonbtn_continue();
        scrollPageDown();
        Thread.sleep(1000);
        addtocart.clickonbtn_finish();
        Thread.sleep(2000);
        addtocart.clickonbtn_backhome();   
        
    }
}
