package testcase;

import base.basetest;
import pages.loginpage;
import utilities.readXLData;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class login extends basetest {
	
	loginpage login;
	
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void login(String Email, String password) throws InterruptedException, IOException {

		

		login = new loginpage(driver);
		login.enterEmail(Email);
		login.enterPassword(password);
		login.clickonbtn_login();
		
	}
}

  
