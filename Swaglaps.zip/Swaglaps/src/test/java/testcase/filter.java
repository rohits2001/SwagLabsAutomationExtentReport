package testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import base.basetest;
import pages.filterpage;
import pages.loginpage;
import utilities.readXLData;

public class filter extends basetest{
	
loginpage login;
filterpage filter;
	
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void login(String Email, String password) throws InterruptedException, IOException {

		
        filter = new filterpage(driver);
		
		login = new loginpage(driver);
		login.enterEmail(Email);
		login.enterPassword(password);
		login.clickonbtn_login();
		
    	filter.clickonbtn_btn_filter();
		filter.clickon_filter();
		
	}

}
