package testcase;

import java.io.IOException;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.basetest;
import pages.aboutpage;
import pages.loginpage;
import utilities.readXLData;


@Listeners(base.Listeners.class)
public class about extends basetest {
	
	
loginpage login;
aboutpage about;
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void aboutdata(String Email, String password) throws InterruptedException, IOException {

		about = new aboutpage(driver);

		login = new loginpage(driver);
		login.enterEmail(Email);
		login.enterPassword(password);
		login.clickonbtn_login();
		
		about.clickonbtn_menuTab();
		about.clickonbtn_about();	
		
	}
}
