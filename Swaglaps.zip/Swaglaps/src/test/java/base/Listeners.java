package base;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;
import utilities.takescreenshot;

public class Listeners extends basetest implements ITestListener {

    @Override
    public void onTestStart(ITestResult result) {
        // Create a new test in the extent report
        extentTest = extentReports.createTest(result.getMethod().getMethodName());

        // Adding test description
        String description = result.getMethod().getDescription();
        if (description != null && !description.isEmpty()) {
            extentTest.log(Status.INFO, "Test Description: " + description);
        }

        // Assigning authors and categories
        extentTest.assignAuthor("Rohit Singh");
        extentTest.assignCategory("Regression", "Smoke Test");

        // Adding custom message
        extentTest.info("Test started with description: " + result.getMethod().getDescription());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        // Log success message
        extentTest.log(Status.PASS, "Test passed");

        // Adding test duration
        long duration = result.getEndMillis() - result.getStartMillis();
        extentTest.info("Test executed in: " + duration + " milliseconds");

        // Attaching a screenshot for passed test
        try {
            String screenshotPath = takescreenshot.captureScreenshot(driver, result.getMethod().getMethodName() + "_Pass");
            extentTest.pass("Test passed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            extentTest.log(Status.WARNING, "Failed to capture pass screenshot: " + e.getMessage());
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        // Log failure message
        extentTest.log(Status.FAIL, "Test failed");

        // Adding failure details
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            extentTest.log(Status.FAIL, "Error: " + throwable.getMessage());
        }

        // Adding test duration
        long duration = result.getEndMillis() - result.getStartMillis();
        extentTest.info("Test executed in: " + duration + " milliseconds");

        // Attaching a screenshot for failed test
        try {
            String screenshotPath = takescreenshot.captureScreenshot(driver, result.getMethod().getMethodName() + "_Fail");
            extentTest.fail("Test failed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            extentTest.log(Status.WARNING, "Failed to capture fail screenshot: " + e.getMessage());
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        // Log skipped tests
        extentTest.log(Status.SKIP, "Test skipped");

        // Attaching a screenshot for skipped test
        try {
            String screenshotPath = takescreenshot.captureScreenshot(driver, result.getMethod().getMethodName() + "_Skipped");
            extentTest.skip("Test skipped", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            extentTest.log(Status.WARNING, "Failed to capture skipped screenshot: " + e.getMessage());
        }
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // Log this test case as partially successful
        extentTest.log(Status.INFO, "Test failed but within success percentage: " + result.getMethod().getMethodName());
    }

    @Override
    public void onStart(ITestContext context) {
        // Add system information at the start of the test suite
        extentReports.setSystemInfo("Browser", "Chrome");
        extentReports.setSystemInfo("OS", "Windows 11");
        extentReports.setSystemInfo("Test Environment", "Staging");
    }

    @Override
    public void onFinish(ITestContext context) {
        // Generate the final report
        extentReports.flush();
    }
}
