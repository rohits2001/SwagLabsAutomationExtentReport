package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.basetest;

public class loginpage extends basetest {
	
	WebElement txt_email;
	WebElement txt_password;
	WebElement btn_login;
	WebElement btn_continue;
	
	public loginpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	public void enterEmail(String Email) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_email"))))
				.sendKeys(Email);
	}
	
	public void enterPassword(String password) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_password"))))
				.sendKeys(password);
	}
	
	public void clickonbtn_login() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_login")))).click();
	}
	
	public void clickonbtn_continue() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_continue")))).click();
	}
}
