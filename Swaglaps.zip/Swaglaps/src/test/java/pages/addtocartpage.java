package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import base.basetest;

public class addtocartpage extends basetest{

    WebDriver driver;
    
    WebElement btn_addtocart;
    WebElement btn_gotocart;
    WebElement btn_checkout;
    WebElement txt_firstname;
    WebElement txt_lastname;
    WebElement txt_zipcode;
    WebElement btn_continue;
    WebElement btn_finish;
    WebElement btn_backhome;

    // Constructor to initialize driver
    public addtocartpage(WebDriver driver) {
        this.driver = driver;
    }

    // Locator for Add to Cart button (SauceLabsBackpack)
    public void clickonbtn_addtocart() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_addtocart")))).click();	
	}
    
    // Locator for Go to Cart button (SauceLabsBackpack)
    public void clickonbtn_gotocart() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_gotocart")))).click();	
	}
    
    // Locator for Checkout button (SauceLabsBackpack)
    public void clickonbtn_checkout() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_checkout")))).click();	
	}
    
    public void enterfirstname(String firstname) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_firstname"))))
				.sendKeys(firstname);
	}
    
    public void enterlastname(String lastname) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_lastname"))))
				.sendKeys(lastname);
	}
    
    public void enterzipcode(String zipcode) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_zipcode"))))
				.sendKeys(zipcode);
	}
    
    // Locator for Continue button
    public void clickonbtn_continue() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_continue")))).click();	
	}
    
    // Locator for finish button
    public void clickonbtn_finish() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_finish")))).click();	
	}
    
 // Locator for finish button
    public void clickonbtn_backhome() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_backhome")))).click();	
	}
}