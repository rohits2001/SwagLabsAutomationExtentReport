package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import base.basetest;

public class logoutpage extends basetest{

    WebDriver driver;
    
    WebElement btn_menu;
    WebElement btn_logout;

    // Constructor to initialize driver
    public logoutpage(WebDriver driver) {
        this.driver = driver;
    }
   
 // Locator for menu button
    public void clickonbtn_menu() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_menu")))).click();	
	}
    
    // Locator for logout button
    public void clickonbtn_logout() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_logout")))).click();	
	}
}