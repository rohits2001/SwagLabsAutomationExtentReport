package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import base.basetest;

public class filterpage extends basetest{
	
	WebElement optionvalue;
	WebElement btn_filter;
	
	public filterpage(WebDriver driver) {
        this.driver=driver;
  }
	
	public void clickon_filter() {
		btn_filter = driver.findElement(By.xpath(loc.getProperty("btn_filter")));
		Select select = new Select(btn_filter);
		select.selectByIndex(3);
	}
	
   
	public void clickonbtn_btn_filter() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_filter")))).click();	
	}
	
};
