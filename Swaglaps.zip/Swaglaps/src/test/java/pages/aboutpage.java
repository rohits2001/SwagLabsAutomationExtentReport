package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.basetest;

public class aboutpage extends basetest{
	
	
	WebElement btn_menu;
	WebElement btn_about;
	WebElement btn_menuTab;
	
	 public aboutpage(WebDriver driver) {
	        this.driver = driver;
	    }
	 
	 public void clickonbtn_about() {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_about")))).click();	
		}

	 public void clickonbtn_menuTab() {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_menuTab")))).click();	
		}
	 
}
