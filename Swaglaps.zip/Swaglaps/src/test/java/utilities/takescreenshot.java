package utilities;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class takescreenshot {

    // Method to take a screenshot and return its path
    public static String captureScreenshot(WebDriver driver, String screenshotName) throws IOException {
        // Cast the WebDriver to TakesScreenshot
        TakesScreenshot ts = (TakesScreenshot) driver;

        // Get the screenshot as a file
        File source = ts.getScreenshotAs(OutputType.FILE);

        // Format the screenshot name with a timestamp
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String destination = "./screenshots/" + screenshotName + "_" + timestamp + ".png";

        // Create a directory if it doesn't exist
        File destinationFile = new File(destination);
        destinationFile.getParentFile().mkdirs();

        // Copy the screenshot file to the desired location
        FileHandler.copy(source, destinationFile);

        System.out.println("Screenshot saved to " + destinationFile.getAbsolutePath());

        // Return the absolute path of the screenshot
        return destinationFile.getAbsolutePath();
    }
}
